//
//  NSObject+Extension.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import Foundation

//========================================
//MARK:-
//MARK: - NSObject
//========================================
extension NSObject {
    static var identifier: String {
        return NSStringFromClass(self).components(separatedBy: ".").last ?? ""
    }
}

