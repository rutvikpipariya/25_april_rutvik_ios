//
//  UITableView+Extension.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import Foundation
import UIKit

//========================================
//MARK:-
//MARK: - UITableView
//========================================
extension UITableView {
    func configureTable(vc: UIViewController, identifier: String) {
        self.register(UINib(nibName: identifier, bundle: nil), forCellReuseIdentifier: identifier)
        self.delegate = vc as? UITableViewDelegate
        self.dataSource = vc as? UITableViewDataSource
    }
}

