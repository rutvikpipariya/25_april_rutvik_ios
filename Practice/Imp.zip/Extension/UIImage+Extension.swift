//
//  UIImage+Extension.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import Foundation
import UIKit

enum Images: String {
    case your_image_name_from_assets
}

extension UIImage {
    convenience init?(_ name: Images, in bundle: Bundle = Bundle.main) {
        self.init(named: name.rawValue, in: bundle, compatibleWith: nil)
    }
}

