//
//  UICollectionView+Extension.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import Foundation
import UIKit

//========================================
//MARK:-
//MARK: - UICollectionView
//========================================
extension UICollectionView {
    func configureCollection(vc: UIViewController, identifier: String) {
        self.register(UINib(nibName: identifier, bundle: nil), forCellWithReuseIdentifier: identifier)
        self.delegate = vc as? UICollectionViewDelegate
        self.dataSource = vc as? UICollectionViewDataSource
    }
}

