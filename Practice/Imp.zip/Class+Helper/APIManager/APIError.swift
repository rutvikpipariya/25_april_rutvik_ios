import Foundation

//========================================
//MARK:-
//MARK: - APIError
//========================================
enum APIError: Error {
    case invalidPath
    case decoding
    case network
    case unauthorized
    case forbidden
    case timeout
    case serverError
    case notFound
    case emptyResponse
    case badRequest
}

extension APIError {
    var localizedDescription: String {
        switch self {
        case .invalidPath:
            return "Invalid Path"
        case .decoding:
            return "There was an error decoding the type"
        case .network:
            return "Network connectivity issue. Please check your internet connection."
        case .unauthorized:
            return "Unauthorized request. Please check your credentials."
        case .forbidden:
            return "Forbidden access. You do not have permission to access this resource."
        case .timeout:
            return "The request timed out. Please try again later."
        case .serverError:
            return "There was an issue with the server. Please try again later."
        case .notFound:
            return "The requested resource was not found."
        case .emptyResponse:
            return "The server returned no data."
        case .badRequest:
            return "The request was malformed or invalid."
        }
    }
}
