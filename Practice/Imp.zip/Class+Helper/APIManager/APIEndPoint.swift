//import Foundation
//import Alamofire
//
////========================================
////MARK:-
////MARK: - APIEndPoint
////========================================
//enum APIEndPoint {
//    case instructor
//    
//    enum Method: String {
//        case POST
//    }
//}
//
//extension APIEndPoint {
//    var path: String {
//        switch self {
//        case .instructor:
//            return "/InstructorStudentList"
//        }
//    }
//    
//    var method: APIEndPoint.Method {
//        switch self {
//        case .instructor:
//                .POST
//        }
//    }
//    
//    var parameter: [URLQueryItem]? {
//        switch self {
//        case .instructor:
//            return nil
//        }
//    }
//    
//    var headers: HTTPHeaders {
//        return [
//            "HashToken": "79f293dc-2cce-49ae-ae44-93669d4c7d7f",
//            "Content-Type": "application/json"
//        ]
//    }
//    
//    var url: String {
//        return apiURL + path
//    }
//}

import Foundation
import Alamofire

//========================================
//MARK:-
//MARK: - APIEndPoint
//========================================
enum APIEndPoint {
    case instructor
    
    enum Method: String {
        case POST
    }
}

extension APIEndPoint {
    var path: String {
        switch self {
        case .instructor:
            return "/InstructorStudentList"
        }
    }
    
    var method: APIEndPoint.Method {
        switch self {
        case .instructor:
                .POST
        }
    }
    
    var parameter: [URLQueryItem]? {
        switch self {
        case .instructor:
            return nil
        }
    }
    
    var headers: HTTPHeaders {
        return nil
    }
    
    var url: String {
        return apiURL + path
    }
}
