//import Alamofire
//
////========================================
////MARK:-
////MARK: - APIManager
////========================================
//class APIManager {
//    static let sharedInstance = APIManager()
//    private init() {}
//
//    func fetchInstructorStudents(page: Int, completion: @escaping (Result<StudentModel, APIError>) -> Void) {
//        let parameters: [String: Any] = [
//            "InstructorId": "1477",
//            "LocationId": "1",
//            "Year": "2024",
//            "StudentPayType": "ALL",
//            "StudentPaymentType": "",
//            "StudentType": "",
//            "SearchTitle": "",
//            "SPageNo": "1",
//            "EvaluationType": ""
//        ]
//
//        AF.request(APIEndPoint.instructor.url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: APIEndPoint.instructor.headers)
//            .responseDecodable(of: StudentModel.self) { response in
//                switch response.result {
//                case .success(let studentData):
//                    completion(.success(studentData))
//                case .failure(let error):
//                    print("Request failed with error: \(error)")
//                }
//            }
//
//    }
//}

//========================================
//MARK:-
//MARK: - APIManager
//========================================
final class APIManager {
    static let sharedInstance = APIManager()
    private init() {}
    
    func fetchInstructorStudents(page: Int, completion: @escaping (Result<StudentModel, APIError>) -> Void) {
        AF.request(APIEndPoint.instructor.url, method: .post, encoding: JSONEncoding.default, headers: APIEndPoint.instructor.headers)
            .responseDecodable(of: StudentModel.self) { response in
                switch response.result {
                case .success(let studentData):
                    completion(.success(studentData))
                case .failure(let error):
                    print("Request failed with error: \(error)")
                }
            }
    }
}
