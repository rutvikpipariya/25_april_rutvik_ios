//
//  Constant.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import Foundation
import UIKit

let sceneDelegate = (UIApplication.shared.connectedScenes.first?.delegate) as? SceneDelegate
/*
 :- Make root view controller using below code
 let storyBoard = UIStoryboard(name: "Main", bundle: nil)
 if let goToHomeVC = storyBoard.instantiateViewController(withIdentifier: ViewController.identifier) as? ViewController {
     let nav = UINavigationController(rootViewController: goToHomeVC)
     sceneDelegate?.window?.rootViewController = nav
     sceneDelegate?.window?.makeKeyAndVisible()
 }
 */
