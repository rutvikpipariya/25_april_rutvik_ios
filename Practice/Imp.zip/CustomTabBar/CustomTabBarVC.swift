//
//  CustomTabBarVC.swift
//  TestingDemo
//
//  Created by Rutvik Pipaliya on 06/12/24.
//

import UIKit

class CustomTabBarVC: UIViewController {
    
    @IBOutlet weak var tabBarView: UIView!
    @IBOutlet weak var superView: UIView!
    @IBOutlet var buttons: [UIButton]!
    
    private var previousSelectedButton: UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarView.layer.cornerRadius = 30
        self.tabBarView.clipsToBounds = true
        if let starButton = buttons.first(where: { $0.tag == 3 }) {
            previousSelectedButton = starButton
            if let starVC = storyboard?.instantiateViewController(withIdentifier: "StarVC") as? StarVC {
                displayContentController(starVC)
            }
        }
    }
    
    @IBAction func tabButtons(_ sender: UIButton) {
        let tag = sender.tag
        var selectedVC: UIViewController?

        switch tag {
        case 1:
            selectedVC = storyboard?.instantiateViewController(withIdentifier: "HomeVC") as? HomeVC
        case 2:
            selectedVC = storyboard?.instantiateViewController(withIdentifier: "PersonVC") as? PersonVC
        case 3:
            selectedVC = storyboard?.instantiateViewController(withIdentifier: "StarVC") as? StarVC
        case 4:
            selectedVC = storyboard?.instantiateViewController(withIdentifier: "CalenderVC") as? CalenderVC
        case 5:
            selectedVC = storyboard?.instantiateViewController(withIdentifier: "SettingVC") as? SettingVC
        default:
            break
        }

        if let selectedVC = selectedVC {
            displayContentController(selectedVC)
        }
    }
    
    private func displayContentController(_ content: UIViewController) {
        for child in children {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
        }
        addChild(content)
        content.view.frame = superView.bounds
        superView.addSubview(content.view)
        content.didMove(toParent: self)
    }
}


class HomeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

class SettingVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("view did load")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("view will appear")
    }
    
}

class StarVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

class CalenderVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

class PersonVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}
